import json
import os

# Use an absolute path to ensure the file is created in the correct location
KNOWLEDGE_BASE_FILE = os.path.join(os.getcwd(), "chatbot_knowledge.json")

# Load or initialize the knowledge base
def load_knowledge():
    if os.path.exists(KNOWLEDGE_BASE_FILE):
        if os.path.getsize(KNOWLEDGE_BASE_FILE) > 0:
            try:
                with open(KNOWLEDGE_BASE_FILE, "r") as file:
                    data = json.load(file)
                    print("[✓] Loaded existing knowledge base.")
                    return data
            except json.JSONDecodeError:
                print("[!] JSON file was corrupt. Starting fresh.")
    print("[✓] No previous knowledge base found. Starting fresh.")
    return {}

# Save knowledge to file
def save_knowledge(knowledge_base):
    with open(KNOWLEDGE_BASE_FILE, "w") as file:
        json.dump(knowledge_base, file, indent=4)
    print("[✓] Knowledge saved to", KNOWLEDGE_BASE_FILE)

# Get or teach a response
def get_response(user_input, knowledge_base):
    user_input = user_input.lower()
    if user_input in knowledge_base:
        return knowledge_base[user_input]
    else:
        response = input(f"I don't know how to respond to '{user_input}'. How should I reply? ")
        knowledge_base[user_input] = response
        save_knowledge(knowledge_base)
        return response

# Main chatbot loop
def chat():
    print("🤖 Chatbot started. Type 'exit' to quit.")
    knowledge_base = load_knowledge()
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("🤖 Goodbye!")
            break
        reply = get_response(user_input, knowledge_base)
        print(f"Bot: {reply}")

if __name__ == "__main__":
    chat()
